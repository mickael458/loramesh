#include "TelemetrySensor.h"
#include "../mesh/generated/meshtastic/telemetry.pb.h"
#include "NodeDB.h"
#include "main.h"
