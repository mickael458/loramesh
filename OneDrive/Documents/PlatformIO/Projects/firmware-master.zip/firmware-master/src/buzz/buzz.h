#pragma once

void playBeep();
void playStartMelody();
void playShutdownMelody();
